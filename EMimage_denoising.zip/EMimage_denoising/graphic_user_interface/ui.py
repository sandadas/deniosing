import subprocess
import sys

# check packages
def check_and_install(package):
    try:
        __import__(package)
        print(f"{package} Installed")
    except ImportError:
        print(f"{package} Uninstalled, installing...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])

required_packages = [
    "tifffile", "numpy", 'n2v', "csbdeep", "matplotlib",
    "PIL", "pickle", "torch", 'pyiqa', "os", "gc", "shutil","tkinter", "PIL", "tifffile",
]

for package in required_packages:
    check_and_install(package)

import tkinter as tk
from tkinter import filedialog, messagebox
from tkinter import *
from PIL import Image, ImageTk
import os
import sys
import image_processor
from image_processor import process_image  # import process_image
import tifffile as tiff
import numpy as np

class ImageApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Image Processor")
        self.root.geometry('500x600')
        self.root.resizable(False, False)

        self.image_label = Label(root, text="No image loaded", bg="gray")
        self.image_label.place(x=25, y=25, width=450, height=450)

        self.load_button = Button(root, text="Load Image", command=self.load_image)
        self.load_button.place(x=50, y=500, width=100, height=30)

        self.process_button = Button(root, text="Process Image", command=self.process_image)
        self.process_button.place(x=200, y=500, width=100, height=30)

        self.save_button = Button(root, text="Save Image", command=self.save_image)
        self.save_button.place(x=350, y=500, width=100, height=30)

        self.exit_button = Button(root, text="Exit", command=self.exit_app)
        self.exit_button.place(x=200, y=550, width=100, height=30)

        self.image = None
        self.image_array = None
        self.processed_image = None
        self.processed_image_array = None


    def load_image(self):
        file_path = filedialog.askopenfilename(filetypes=[
            ("All image files", "*.jpg *.jpeg *.png *.bmp *.gif *.tif *.tiff"),
            ("JPEG files", "*.jpg;*.jpeg"),
            ("PNG files", "*.png"),
            ("BMP files", "*.bmp"),
            ("GIF files", "*.gif"),
            ("TIFF files", "*.tif")
        ])
        if file_path:
            self.image = Image.open(file_path)
            self.image_array = np.array(self.image).astype("float32")
            if len(self.image_array.shape) == 3:
                self.image_array = np.dot(self.image_array[...,:3],[0.2989,0.5870,0.1140])
            self.show_image(self.image)
            self.image_label.config(text=os.path.basename(file_path))

    def show_image(self, image):
        max_width, max_height = 450, 450
        img_width, img_height = image.size

        if img_width > max_width or img_height > max_height:
            image = image.resize((max_width, max_height), Image.ANTIALIAS)

        tk_image = ImageTk.PhotoImage(image)
        self.image_label.config(image=tk_image)
        self.image_label.image = tk_image

    def process_image(self):
        self.processed_image,self.processed_image_array= process_image(self.image,self.image_array)
        if self.processed_image:
            
            self.show_image(self.processed_image)

    def save_image(self):
        if self.processed_image:
            file_path = filedialog.asksaveasfilename(defaultextension="*.tif",
                                                     filetypes=[
                                                         ("JPEG files", "*.jpg"),
                                                         ("PNG files", "*.png"),
                                                         ("BMP files", "*.bmp"),
                                                         ("TIFF files", "*.tif")
                                                     ])
            if file_path:
                tiff.imwrite(file_path,self.processed_image_array.astype(np.uint8))
                messagebox.showinfo("Image Processor", "Image saved successfully.")
        else:
            messagebox.showwarning("Image Processor", "Please process an image first.")

    def exit_app(self):
        self.root.quit()
        self.root.destroy()
        sys.exit()

if __name__ == "__main__":
    root = tk.Tk()
    app = ImageApp(root)
    root.mainloop()
