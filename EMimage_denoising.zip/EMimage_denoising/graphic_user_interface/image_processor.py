
from tkinter import messagebox
from PIL import Image
import tifffile as tiff
import numpy as np
from n2v.models import N2VConfig, N2V
from csbdeep.utils import plot_history
from n2v.utils.n2v_utils import manipulate_val_data
from n2v.internals.N2V_DataGenerator import N2V_DataGenerator
from matplotlib import pyplot as plt
import tifffile as tiff
import pickle
import torch
from pyiqa import create_metric
import os
import gc
import time
import shutil
def load_image(path):
    # This function is used to load grayscale images, if the number of channels in the image is three, the channel will be converted to one
    tif_image = tiff.imread(path)
    tif_array = np.array(tif_image).astype('float32')
    if len(tif_array.shape) == 3:
        tif_array = np.dot(tif_array[...,:3], [0.2989, 0.5870, 0.1140]).astype("float32")
    return tif_array

def split_array_with_dynamic_step(array, block_size=(256, 256), step=128):
    h, w = array.shape
    block_h, block_w = block_size
    blocks = []
    positions = []
    i = 0
    while i < h:
        if i + block_h > h:
            i = h - block_h  # Adjust i to fit the last block
        j = 0
        while j < w:
            if j + block_w > w:
                j = w - block_w  # Adjust j to fit the last block
            block = array[i:i + block_h, j:j + block_w]
            blocks.append(block)
            pos = np.zeros((block_h, block_w, 2), dtype=int)
            for m in range(block_h):
                for n in range(block_w):
                    pos[m, n] = (i + m, j + n)
            positions.append(pos)
            if j + block_w >= w:
                break
            j += step
        if i + block_h >= h:
            break
        i += step
    return blocks, positions

def reconstruct_image(blocks, positions, original_shape):
    h, w = original_shape
    reconstructed_image = np.zeros((h, w), dtype=float)
    count = np.zeros((h, w), dtype=int)

    for block, pos in zip(blocks, positions):
        block_h, block_w = block.shape
        for i in range(block_h):
            for j in range(block_w):
                x, y = pos[i, j]
                reconstructed_image[x, y] += block[i, j]
                count[x, y] += 1

    # Average the overlapping regions
    count[count == 0] = 1  # Prevent division by zero
    reconstructed_image /= count
    reconstructed_image = reconstructed_image.astype("float32")
    return reconstructed_image

def calculate_variances_and_sort(arrays):
    variances = [np.var(array) for array in arrays]
    #sorted_index = np.argsort(variances)[::-1]
    sorted_index = np.argsort(variances)
    return sorted_index, variances

def Uniform_size(image_npy,h,w):
    image = Image.fromarray(image_npy)
    resized_image = image.resize((w,h))
    resized_image_npy=np.array(resized_image)
    return resized_image_npy
def dataprocessing(imgs,patch_size):
    p_imgs = []
    for img in imgs:
        h,w = img.shape
        p_img = img.reshape(1, h, w, 1)
        p_imgs.append(p_img)
    datagen = N2V_DataGenerator()
    patch_shape = (patch_size,patch_size)
    patches = datagen.generate_patches_from_list(p_imgs, shape=patch_shape)
    train_val_split = int(patches.shape[0] * 0.8)
    X = patches[:train_val_split]
    X_val = patches[train_val_split:]
    return imgs, X, X_val

def get_batch_size(patch_size):
    memory_limit = 4096
    batch_size = 4096/patch_size
    return int(batch_size)

def get_iq_score(image,evaluator):
    #["liqe","nrqm","maniqa-kadid","tres"]
    device = torch.device("cpu")
    image_tensor = torch.tensor(image/255).unsqueeze(0).unsqueeze(0)
    iqe_metric = create_metric(evaluator,device=device)
    print(iqe_metric.lower_better)
    iqe_score = iqe_metric(image_tensor)
    score = iqe_score.item()

    # Clean up: delete variables and free memory
    del image_tensor
    del iqe_metric
    del iqe_score
    torch.cuda.empty_cache()
    gc.collect()
    return score

def get_pick_size(n):
    pick_size = n//10
    if not pick_size % 2:
        return pick_size
    else:
        return pick_size-1

def get_batch_size(patch_size):
    memory_limit = 4096
    batch_size = 4096/patch_size
    return int(batch_size)

def get_iq_score(image,evaluator):
    #["liqe","nrqm","maniqa-kadid","tres"]
    device = torch.device("cpu")
    image_tensor = torch.tensor(image/255).unsqueeze(0).unsqueeze(0)
    iqe_metric = create_metric(evaluator,device=device)
    print(iqe_metric.lower_better)
    iqe_score = iqe_metric(image_tensor)
    score = iqe_score.item()

    # Clean up: delete variables and free memory
    del image_tensor
    del iqe_metric
    del iqe_score
    torch.cuda.empty_cache()
    gc.collect()
    return score

def get_pick_size(n):
    pick_size = n//10
    if not pick_size % 2:
        return pick_size
    else:
        return pick_size-1

def get_batch_size(patch_size):
    memory_limit = 4096
    batch_size = 4096/patch_size
    return int(batch_size)

def get_iq_score(image,evaluator):
    #["liqe","nrqm","maniqa-kadid","tres"]
    device = torch.device("cpu")
    image_tensor = torch.tensor(image/255).unsqueeze(0).unsqueeze(0)
    iqe_metric = create_metric(evaluator,device=device)
    print(iqe_metric.lower_better)
    iqe_score = iqe_metric(image_tensor)
    score = iqe_score.item()

    # Clean up: delete variables and free memory
    del image_tensor
    del iqe_metric
    del iqe_score
    torch.cuda.empty_cache()
    gc.collect()
    return score

def get_pick_size(n):
    pick_size = n//10
    if not pick_size % 2:
        return pick_size
    else:
        return pick_size-1


def get_max_loop(n):
    # max_loop = 2*n//pick_size -1
    max_loop = n // 16
    return max_loop


def check_image_size(img):
    img_h, img_w = img.shape
    if (img_w >= 2048 and img_h >= 2048) or (img_h >= 2048 and img_w >= 2048):
        return True
    return False


def init_and_train_model(parameters, model_name, X, X_val):
    train_batch = parameters[0]
    t_e = parameters[1]
    patch_size = parameters[2]
    config = N2VConfig(X, unet_kern_size=3,
                       unet_n_first=64, unet_n_depth=3, train_steps_per_epoch=int(X.shape[0] / train_batch),
                       train_epochs=t_e, train_loss='mse',
                       batch_norm=True, train_batch_size=train_batch, n2v_perc_pix=0.198,
                       n2v_patch_shape=(patch_size, patch_size),
                       n2v_manipulator='uniform_withCP', n2v_neighborhood_radius=5)
    model_name = model_name
    basedir = 'models'
    model = N2V(config, model_name, basedir=basedir)
    history = model.train(X, X_val)
    return model

def load_and_train_model(parameters,model_name,X,X_val):
    train_batch = parameters[0]
    t_e = parameters[1]
    patch_size = parameters[2]
    model_weights_path = "./model_current/weights_best.h5"
    config = N2VConfig(X, unet_kern_size=3,
                           unet_n_first=64, unet_n_depth=3, train_steps_per_epoch=int(X.shape[0]/train_batch), train_epochs=t_e, train_loss='mse',
                           batch_norm=True, train_batch_size=train_batch, n2v_perc_pix=0.198, n2v_patch_shape=(patch_size, patch_size),
                           n2v_manipulator='uniform_withCP', n2v_neighborhood_radius=5)
    model_name = model_name
    basedir = 'models'
    model = N2V(config, model_name, basedir=basedir)
    model.keras_model.load_weights(model_weights_path)
    history = model.train(X, X_val)
    return model

def save_best_model_weight(model_name):
    src = f"./models/{model_name}/weights_best.h5"
    dst = "./model_best/weights_best.h5"
    shutil.copy(src, dst)

def save_current_model_weight(model_name):
    src = f"./models/{model_name}/weights_best.h5"
    dst = "./model_current/weights_best.h5"
    shutil.copy(src, dst)

def get_train_epoch(n):
    if n == 0:
      return 100
    elif n == 1:
      return 50
    else:
      return 20

def load_best_model(parameters,model_name,X):
    train_batch = parameters[0]
    t_e = parameters[1]
    patch_size = parameters[2]
    model_weights_path = "./model_best/weights_best.h5"
    config = N2VConfig(X, unet_kern_size=3,
                           unet_n_first=64, unet_n_depth=3, train_steps_per_epoch=int(X.shape[0]/train_batch), train_epochs=1, train_loss='mse',
                           batch_norm=True, train_batch_size=train_batch, n2v_perc_pix=0.198, n2v_patch_shape=(patch_size, patch_size),
                           n2v_manipulator='uniform_withCP', n2v_neighborhood_radius=5)
    model_name = model_name
    basedir = 'models'
    model = N2V(config, model_name, basedir=basedir)
    model.keras_model.load_weights(model_weights_path)
    return model


from sklearn.cluster import KMeans


def balance_clusters(X, labels, kmeans):
    counts = np.bincount(labels)
    while max(counts) - min(counts) > 1:
        # Find the class with the most samples and the class with the least
        max_cluster = np.argmax(counts)
        min_cluster = np.argmin(counts)

        # Find the sample closest to the center of the smallest class in the largest class
        max_cluster_indices = np.where(labels == max_cluster)[0]
        min_cluster_center = kmeans.cluster_centers_[min_cluster]

        distances = np.linalg.norm(X[max_cluster_indices] - min_cluster_center, axis=1)
        move_index = max_cluster_indices[np.argmin(distances)]

        # Move the sample to the smallest class
        labels[move_index] = min_cluster

        # Recalculate the sample size for each class
        counts = np.bincount(labels)

    return labels


def get_cluster_index(blocks):
    var = [np.var(i) for i in blocks]
    mean = [np.mean(i) for i in blocks]
    X = np.column_stack((var, mean))
    kmeans = KMeans(n_clusters=8, random_state=0)
    labels = kmeans.fit_predict(X)
    balanced_labels = balance_clusters(X, labels, kmeans)
    plt.scatter(X[:, 0], X[:, 1], c=balanced_labels, cmap='viridis')
    plt.scatter(kmeans.cluster_centers_[:, 0], kmeans.cluster_centers_[:, 1], s=300, c='red', marker='X')
    plt.xlabel('Variance (var)')
    plt.ylabel('Mean (mean)')
    plt.title('Balanced KMeans Clustering')
    plt.show()
    # Check the number of samples for each class
    counts = np.bincount(balanced_labels)
    print(f"Samples per cluster: {counts}")
    cluster_dict = {key: [] for key in range(8)}
    for i in range(len(balanced_labels)):
        cluster_dict[balanced_labels[i]].append(i)
    for key in cluster_dict.keys():
        cluster_dict[key].sort()
        sorted_index, variances = calculate_variances_and_sort([blocks[i] for i in cluster_dict[key]])
        cluster_dict[key] = [cluster_dict[key][i] for i in sorted_index]

    return cluster_dict

if not os.path.isdir('./model_best'):
    os.mkdir('./model_best')

if not os.path.isdir('./model_current'):
    os.mkdir('./model_current')

def denoising(image_array):
    img = image_array
    signal = 1
    n = 0
    sub_blocks = []
    best_score = 0
    max_loop = 1
    no_improve = 0
    max_tolerant = 3
    start_time = time.time()
    while(signal):
        print(n)
        if check_image_size(img):
            if n == 0:
                blocks, positions = split_array_with_dynamic_step(img,(512, 512),512)
                pick_size = get_pick_size(len(blocks))
                max_loop = get_max_loop(len(blocks))
                dict_cluster = get_cluster_index(blocks)
            train_blocks = []
            for i in range(2):
                for i in dict_cluster.keys():
                    train_blocks.append(blocks[dict_cluster[i].pop()])
        else:
            blocks = [img]
            train_blocks = blocks
        t_e = get_train_epoch(n)
        if n == 0:
            patch_size_list = [32,64,128]
            diffp_scores_list = []
            for patch_size in patch_size_list:
                imgs,X,X_val = dataprocessing(train_blocks,patch_size)
                train_batch = get_batch_size(patch_size)
                parameters = [train_batch,t_e,patch_size]
                model_name = f"n2v_{patch_size}_blocks"
                model = init_and_train_model(parameters,model_name,X,X_val)
                pred = model.predict(img,axes='YX',n_tiles=(4,8))
                score = get_iq_score(pred,"nima-spaq")
                diffp_scores_list.append(score)
            best_score = max(diffp_scores_list)
            max_index = diffp_scores_list.index(best_score)
            best_patch_size = patch_size_list[max_index]
            model_name = f"n2v_{best_patch_size}_blocks"
            save_best_model_weight(model_name)
            save_current_model_weight(model_name)
            patch_size = best_patch_size
            train_batch = get_batch_size(patch_size)
            n = n+1
        else:
            imgs,X,X_val = dataprocessing(train_blocks,patch_size)
            parameters = [train_batch,t_e,patch_size]
            model = load_and_train_model(parameters,model_name,X,X_val)
            pred = model.predict(img,axes='YX',n_tiles=(4,8))
            save_current_model_weight(model_name)
            score = get_iq_score(pred,"nima-spaq")
            if score > best_score:
                best_score = score
                save_best_model_weight(model_name)
                no_improve = 0
            else:
                no_improve +=1
            n = n+1
        if n >= max_loop:
            signal = 0
        if no_improve >= max_tolerant:
            signal = 0
    model = load_best_model(parameters,model_name,X)
    pred = model.predict(img,axes='YX',n_tiles=(4,8))
    end_time = time.time()
    #name = path.split("/")[-1][0:-4]
    #np.save(f"./preds/{name}.npy",pred)
    shutil.rmtree("./models")
    return pred

def process_image(image,image_array):
    if image:
        processed_image_array = denoising(image_array)
        processed_image = Image.fromarray(processed_image_array)
        messagebox.showinfo("Image Processor", "Image processed successfully.")
        return processed_image, processed_image_array
    else:
        messagebox.showwarning("Image Processor", "Please load an image first.")
        return None
