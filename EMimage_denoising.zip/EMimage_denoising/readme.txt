This implementation requires TensorFlow. I have tested the code using Python 3.9 and TensorFlow 2.4 and python 2.15 (The version of Tensorflow needs to be below 2.16).


To open the user interface, navigate to the graphic_user_interface directory in the terminal and run the following code.

python3 ui.py

After running ui.py, the program will automatically check and download the required packages. Again, Please ensure that the installed version of TensorFlow is below 2.16.